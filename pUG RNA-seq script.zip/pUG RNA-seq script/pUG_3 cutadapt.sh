#!/bin/bash

# Define input and output directories
input_dir_r1="/public/home/lxr/pUG/seqkit_remove_umi/R1"
input_dir_r2="/public/home/lxr/pUG/seqkit_remove_umi/R2"
output_dir="/public/home/lxr/pUG/20240908_re_count_pUG/Rep1/cutadapt_discard_non_adapter"

# Ensure the output directories exist
mkdir -p "${output_dir}/R1"
mkdir -p "${output_dir}/R2"

# Define adapter sequences and their reverse complementary sequences
adapter1="TTTCACTGGAGTTGTCCCAA"
adapter2="GGCGTCGCCATATTCTACTTACACACACACACACACAC"
adapter1_rc="TTGGGACAACTCCAGTGAAA"
adapter2_rc="GTGTGTGTGTGTGTAAGTAGAATATGGCGACGCC"

# Iterate through files in the R1 directory, assuming each R1 file has a corresponding R2 file
for file_name_r1 in "${input_dir_r1}"/*.fastq; do
    base_name=$(basename "${file_name_r1}" "_R1_dedup.paired.fastq")
    file_name_r2="${input_dir_r2}/${base_name}_R2_dedup.paired.fastq"

    # Define output file paths
    output_file_r1="${output_dir}/R1/${base_name}_rmumi_trimmed_R1.fastq"
    output_file_r2="${output_dir}/R2/${base_name}_rmumi_trimmed_R2.fastq"

    # Use Cutadapt to remove the reverse complementary adapter1 and adapter2 sequences, using 8 cores
    cutadapt \
        -j 8 \
        -q 20 \
        --discard-untrimmed \
        -g "${adapter1}" \
        -a "${adapter2_rc}" \
        -G "${adapter2}" \
        -A "${adapter1_rc}" \
        -o "${output_file_r1}" \
        -p "${output_file_r2}" \
        "${file_name_r1}" \
        "${file_name_r2}"

done

echo "Adapter sequence cleaning completed."
