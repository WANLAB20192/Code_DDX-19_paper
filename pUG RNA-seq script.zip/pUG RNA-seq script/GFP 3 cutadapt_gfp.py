import os
import subprocess

# Define input and output directories
input_dir_r1 = "/public/home/lxr/pUG/1_Rep2/seqkit/R1"
input_dir_r2 = "/public/home/lxr/pUG/1_Rep2/seqkit/R2"
output_dir_r1 = "/public/home/lxr/pUG/1_Rep2/seqkit_trim_for_gfp/R1"
output_dir_r2 = "/public/home/lxr/pUG/1_Rep2/seqkit_trim_for_gfp/R2"

# Ensure the output directory exists
os.makedirs(output_dir_r1, exist_ok=True)
os.makedirs(output_dir_r2, exist_ok=True)

# Define adapter sequences
adapter_r1_5 = "TTTCACTGGAGTTGTCCCAA"
adapter_r2_5 = "GGCGTCGCCATATTCTACTTACACACACACACACACAC"
adapter1_rc = "TTGGGACAACTCCAGTGAAA"

# Traverse all files in the input directory
for file_name_r1 in os.listdir(input_dir_r1):
    if file_name_r1.endswith(".fastq"):
        # Get the corresponding R1 and R2 file paths
        input_file_r1 = os.path.join(input_dir_r1, file_name_r1)
        input_file_r2 = os.path.join(input_dir_r2, file_name_r1.replace("_R1", "_R2"))

        # Define intermediate output file paths
        output_file_r1_step1 = os.path.join(output_dir_r1, file_name_r1.replace(".fastq", "_step1.fastq"))
        output_file_r2_step1 = os.path.join(output_dir_r2, file_name_r1.replace("_R1", "_R2").replace(".fastq", "_step1.fastq"))
        output_file_r1_step2 = os.path.join(output_dir_r1, file_name_r1.replace(".fastq", "_step2.fastq"))
        output_file_r2_step2 = os.path.join(output_dir_r2, file_name_r1.replace("_R1", "_R2").replace(".fastq", "_step2.fastq"))
        output_file_r1_final = os.path.join(output_dir_r1, file_name_r1.replace(".fastq", "_final.fastq"))
        output_file_r2_final = os.path.join(output_dir_r2, file_name_r1.replace("_R1", "_R2").replace(".fastq", "_final.fastq"))

        # 1. Trim low-quality bases
        subprocess.run([
            "cutadapt",
            "-j", "8",  # Use 8 threads
            "-q", "20",
            "-o", output_file_r1_step1,
            "-p", output_file_r2_step1,
            input_file_r1,
            input_file_r2
        ])

        # 2. Trim 5' adapter for R1
        subprocess.run([
            "cutadapt",
            "-j", "8",  # Use 8 threads
            "-g", adapter_r1_5,
            "-o", output_file_r1_step2,
            "--discard-untrimmed",
            output_file_r1_step1
        ])

        # 3. Trim 5' adapter for R2
        subprocess.run([
            "cutadapt",
            "-j", "8",  # Use 8 threads
            "-g", adapter_r2_5,
            "-o", output_file_r2_step2,
            "--discard-untrimmed",
            output_file_r2_step1
        ])

        # 4. If 5' adapter exists in R2, trim it
        subprocess.run([
            "cutadapt",
            "-j", "8",  # Use 8 threads
            "-a", adapter1_rc,
            "-o", output_file_r2_final,
            output_file_r2_step2
        ])

        # Remove intermediate step files
        os.remove(output_file_r1_step1)
        os.remove(output_file_r2_step1)
        os.remove(output_file_r1_step2)
        os.remove(output_file_r2_step2)

print("Trimming complete, well done!")
