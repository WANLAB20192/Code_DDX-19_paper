#!/bin/bash

# Define input and output directories
input_dir="/public/home/lxr/pUG/1_Rep2/seqkit_align_gfp/sam"  # Replace with your SAM files directory
output_dir="/public/home/lxr/pUG/1_Rep2/seqkit_align_gfp/bam"  # Replace with the desired output directory

# Ensure the output directory exists
mkdir -p "$output_dir"

# Iterate over all SAM files in the input directory
for sam_file in "$input_dir"/*.sam; do
    # Extract base filename without path and extension
    base_name=$(basename "$sam_file" .sam)
    
    # Define paths for intermediate and output files
    bam_file="$output_dir/${base_name}.bam"
    bed_file="$output_dir/${base_name}.bed"
    coverage_file="$output_dir/${base_name}_coverage.bed"
    
    # Step 1: Convert SAM to BAM
    echo "Processing $sam_file -> $bam_file"
    samtools view -Sb "$sam_file" > "$bam_file"
    
    # Step 2: Convert BAM to BED
    echo "Converting $bam_file -> $bed_file"
    bedtools bamtobed -i "$bam_file" > "$bed_file"
    
    # Step 3: Calculate genome coverage
    echo "Calculating coverage for $bam_file -> $coverage_file"
    bedtools genomecov -ibam "$bam_file" -bg > "$coverage_file"
    
    echo "Finished processing $sam_file"
    echo "============================"
done

echo "All SAM files have been processed."
