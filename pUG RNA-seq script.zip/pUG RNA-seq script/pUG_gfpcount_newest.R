# Load necessary libraries
library(ggplot2)
library(dplyr)
library(ggprism)  # Use theme_prism

# Set file path and read data
file_path <- "F:/doctor‘life/outcome/ddx-19/pUG-seq/pUG_gfpcount/Rep2/read_lengths.csv"  # Replace with actual file path
data <- read.csv(file_path)

# View data structure
str(data)

# Create group information (Group)
data$Group <- case_when(
  grepl("index[1-5]_", data$Filename) ~ "F1",
  grepl("index[6-9]_|index10_", data$Filename) ~ "F6",
  grepl("index1[1-5]_", data$Filename) ~ "F9",
  grepl("index1[6-9]_|index20_", data$Filename) ~ "F15",
  TRUE ~ "Other"
)

# Create sample information (Sample)
data$Sample <- case_when(
  grepl("index[1]_|index[6]_|index1[1]_|index1[6]_", data$Filename) ~ "WT",
  grepl("index[2]_|index[7]_|index1[2]_|index1[7]_", data$Filename) ~ "italic('znfx-1(ths434)')",
  grepl("index[3]_|index[8]_|index1[3]_|index1[8]_", data$Filename) ~ "italic('ddx-19(ths636)')",
  grepl("index[4]_|index[9]_|index1[4]_|index1[9]_", data$Filename) ~ "italic('npp-14(ths673)')",
  grepl("index[5]_|index10_|index1[5]_|index20_", data$Filename) ~ "italic('gle-1(ths1041)')",
  TRUE ~ "Other"
)

# Set factor levels for Group and Sample
data$Group <- factor(data$Group, levels = c("F1", "F6", "F9", "F15"))
data$Sample <- factor(data$Sample, levels = c("WT", "italic('znfx-1(ths434)')", "italic('ddx-19(ths636)')", "italic('npp-14(ths673)')", "italic('gle-1(ths1041)')"))

# Calculate log10 of Count
data$LogCount <- log10(data$Count + 1)

# Add interval information
data$Interval <- case_when(
  data$Length >= 1 & data$Length <= 171 ~ "1-171",
  data$Length >= 223 & data$Length <= 376 ~ "223-376",
  data$Length >= 428 & data$Length <= 591 ~ "428-591",
  data$Length >= 643 & data$Length <= 867 ~ "643-867",
  TRUE ~ "Other"
)

# Calculate total reads for each interval
interval_summary <- data %>%
  filter(Interval != "Other") %>%
  group_by(Group, Sample, Interval) %>%
  summarise(Total_Reads = sum(Count))

# Plot bar chart and smooth curve overlay
p <- ggplot(data, aes(x = Length, y = LogCount, fill = Sample)) +
  
  # Draw bar chart
  geom_bar(stat = "identity", position = "identity", alpha = 0.7) +
  
  facet_grid(Group ~ Sample, scales = "fixed", labeller = label_parsed) +
  theme(
    strip.text.y.left = element_blank()  # Completely hide the facet labels on the left of y-axis
  ) +
  
  # Set plot labels
  labs(title = "Read Length Distribution",
       x = NULL,
       y = "log10(Count)") +
  
  # Custom colors
  scale_fill_manual(values = c(
    "WT" = "black",       # Black color
    "italic('znfx-1(ths434)')" = "#1432F5", 
    "italic('ddx-19(ths636)')" = "#EB51F7", 
    "italic('npp-14(ths673)')" = "#EA4025", 
    "italic('gle-1(ths1041)')" = "#88F8FD"
  )) +
  
  # Custom x-axis breaks and labels
  scale_x_continuous(
    breaks = c(1, 171, 222, 376, 427, 591, 642, 867),
    labels = NULL
  ) +
  
  # Use a style similar to that of images
  theme_prism() +
  
  # Adjust details, such as hiding legend, setting label directions, etc.
  theme(
    legend.position = "none",  # Hide legend
    strip.text.y = element_text(angle = 0, hjust = 1),  # Keep facet labels horizontal
    axis.ticks.length = unit(-0.1, "cm"),  # Set tick length, negative value places ticks above x-axis
    axis.ticks = element_line(size = 0.5)  # Set tick line thickness
  )

# Annotate total reads for each interval
# Display annotation in different regions
# Use different y-coordinate values to separate the annotations
p <- p +
  geom_text(data = interval_summary %>% filter(Interval == "1-171"), aes(x = 210, y = 5, label = paste(Total_Reads)),
            hjust = 1.1, size = 3.5, color = "blue", inherit.aes = FALSE, check_overlap = TRUE) +
  geom_text(data = interval_summary %>% filter(Interval == "223-376"), aes(x = 360, y = 5, label = paste(Total_Reads)),
            hjust = 1.1, size = 3.5, color = "blue", inherit.aes = FALSE, check_overlap = TRUE) +
  geom_text(data = interval_summary %>% filter(Interval == "428-591"), aes(x = 540, y = 5, label = paste(Total_Reads)),
            hjust = 1.1, size = 3.5, color = "blue", inherit.aes = FALSE, check_overlap = TRUE) +
  geom_text(data = interval_summary %>% filter(Interval == "643-867"), aes(x = 755, y = 5, label = paste(Total_Reads)),
            hjust = 1.1, size = 3.5, color = "blue", inherit.aes = FALSE, check_overlap = TRUE)

ggsave("gfp_rep2.pdf", p)
# Display plot
print(p)
