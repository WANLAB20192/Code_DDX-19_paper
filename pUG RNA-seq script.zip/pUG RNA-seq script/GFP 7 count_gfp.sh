#!/bin/bash

# Define input directory and output file
input_dir="/public/home/lxr/pUG/1_Rep2/seqkit_align_gfp/bam/final"  # Directory containing BAM files
output_file="/public/home/lxr/pUG/1_Rep2/seqkit_align_gfp/countgfp/read_lengths.csv"  # Path for the output CSV file

# Ensure the output directory exists
mkdir -p "$(dirname "$output_file")"

# Clear or create the output file and add CSV column headers
echo "Filename,Length,Count" > "$output_file"

# Iterate over all the BED files
for bed_file in "$input_dir"/*.bed; do
    # Get the filename without path and extension
    base_name=$(basename "$bed_file" .bed)
    
    # Count the length in the third column and the corresponding read counts
    awk '{lengths[$3]++} END {for (len in lengths) print len, lengths[len]}' "$bed_file" | while read length count; do
        # Record the result in the output CSV file
        echo "${base_name},${length},${count}" >> "$output_file"
    done
    
    echo "Processed $bed_file"
done

echo "All BED files have been processed. Results are in $output_file."
