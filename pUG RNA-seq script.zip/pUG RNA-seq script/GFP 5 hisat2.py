import os
import subprocess
from concurrent.futures import ThreadPoolExecutor

# Define input and output paths
input_dir_r2 = "/public/home/lxr/pUG/1_Rep2/seqkit_cutpUG"
output_dir = "/public/home/lxr/pUG/1_Rep2/seqkit_align_gfp"
log_file = os.path.join(output_dir, "alignment_log.txt")
index_prefix = "gfp_reference_index"

# Create output directory if it doesn't exist
os.makedirs(output_dir, exist_ok=True)

# Get list of R2 files
r2_files = sorted([f for f in os.listdir(input_dir_r2) if f.endswith('.fastq')])

# Define alignment function
def align_file(r2_file):
    r2_path = os.path.join(input_dir_r2, r2_file)
    output_file = os.path.join(output_dir, f"{os.path.splitext(r2_file)[0]}.sam")
    command = ["hisat2", "-x", index_prefix, "-U", r2_path, "-S", output_file, "-p", "8"]
    
    try:
        # Execute command and capture output and errors
        result = subprocess.run(command, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        
        # Extract alignment rate information
        stderr_output = result.stderr.decode('utf-8')
        alignment_rate = None
        for line in stderr_output.split('\n'):
            if "overall alignment rate" in line:
                alignment_rate = line
                break
        
        # Record alignment rate information in the log
        with open(log_file, "a") as log:
            log.write(f"File: {r2_file}\n")
            if alignment_rate:
                log.write(f"Alignment Rate: {alignment_rate}\n")
            else:
                log.write("No alignment rate found\n")
            log.write("\n")  # Add a newline
        
        print(f"Finished processing {r2_file} with alignment rate: {alignment_rate}")
    
    except subprocess.CalledProcessError as e:
        # Record error information in the log
        with open(log_file, "a") as log:
            log.write(f"Error processing {r2_file}: {e.stderr.decode('utf-8')}\n\n")
        print(f"Error processing {r2_file}")

# Use ThreadPoolExecutor for parallel processing
with ThreadPoolExecutor(max_workers=4) as executor:
    for r2_file in r2_files:
        executor.submit(align_file, r2_file)
