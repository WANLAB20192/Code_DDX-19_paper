#!/bin/bash

# Define input and output directories
input_dir="/public/home/lxr/pUG/1_Rep2/seqkit_trim_for_gfp/R2"
output_dir="/public/home/lxr/pUG/1_Rep2/seqkit_cutpUG"
log_file="$output_dir/process_log.txt"

# Ensure the output directory exists
mkdir -p "$output_dir"

# Clear the log file
echo "Processing Log" > "$log_file"
echo "===================" >> "$log_file"

# Traverse all R2 files in the input directory
for input_file in "$input_dir"/*_R2_dedup.paired_final.fastq; do
    # Get the output file path
    output_file="$output_dir/$(basename "$input_file")"
    
    # Process the file, remove multiple AC repeated sequences and their previous content, and log it
    awk -v log_file="$log_file" 'BEGIN {OFS = "\n"} 
        NR % 4 == 2 {
            original_seq = $0
            ac_count = gsub(/AC/, "&")  # Count the number of AC repeats
            if (ac_count > 1) {  # Only process if AC repeats multiple times
                match($0, /^(AC)+/)
                processed_seq = substr($0, RLENGTH + 1)
                $0 = processed_seq
                # Log the changes
                print "Original Sequence: " original_seq >> log_file
                print "Processed Sequence: " $0 >> log_file
                print "------------------------" >> log_file
            }
        }
        NR % 4 == 0 {
            if (ac_count > 1 && match(original_seq, /^(AC)+/)) {
                $0 = substr($0, RLENGTH + 1)
            }
        }
        {print}' "$input_file" > "$output_file"
    
done

echo "All R2 files have been processed and logged in the log file: $log_file"
