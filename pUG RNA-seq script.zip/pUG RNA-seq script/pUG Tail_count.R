library(ggplot2)
library(dplyr)
library(tidyr)
library(ggprism)

# Define the input directory and file list
input_dir <- "F:/doctor‘life/outcome/ddx-19/pUG-seq/pUG_tail_count_final/Rep2"

#index1-5
#file_list <- list.files(input_dir, pattern = "index[1-5]_.*_ac_count\\.csv$", full.names = TRUE)
#index6-10
#file_list <- list.files(input_dir, pattern = "index[6-9]_.*_ac_count\\.csv$|index10_.*_ac_count\\.csv$", full.names = TRUE)
#index11-15
#file_list <- list.files(input_dir, pattern = "index1[1-5]_.*_ac_count\\.csv$", full.names = TRUE)
#index16-20
file_list <- list.files(input_dir, pattern = "index1[6-9]_.*_ac_count\\.csv$|index20_.*_ac_count\\.csv$", full.names = TRUE)

# Define the mapping from file name to group label
file_to_group <- c("index16" = "WT", 
                   "index17" = "znfx-1(ths434)", 
                   "index18" = "ddx-19(ths636)", 
                   "index19" = "npp-14(ths673)", 
                   "index20" = "gle-1(ths1041)")

# Read all files and combine them into one data frame
all_data <- lapply(file_list, function(file) {
  data <- read.csv(file)
  base_name <- basename(file)
  group_name <- sub("_.*", "", base_name)
  data$Group <- file_to_group[group_name]
  return(data)
}) %>% bind_rows()

# Transform the Count column
all_data <- all_data %>%
  mutate(Transformed_Count = log10(Count),
         Transformed_AC_Length = CA_AC_Length)

p <- ggplot(all_data, aes(x = Transformed_AC_Length, y = Transformed_Count, color = Group, linetype = Group, group = Group)) +
  geom_line() +
  scale_y_continuous(limits = c(0, 4.5)) +
  scale_x_continuous(limits = c(0, 70), breaks = c(0, 20, 40, 60)) +  # Set the X-axis range from 0 to 120
  geom_smooth(se = FALSE) +
  labs(x = "poly(UG) Length",
       y = "log10(Read Counts)") +
  scale_color_manual(values = c("WT" = "black", 
                                "znfx-1(ths434)" = "#1432F5", 
                                "ddx-19(ths636)" = "#EB51F7", 
                                "npp-14(ths673)" = "#EA4025", 
                                "gle-1(ths1041)" = "#88F8FD"),
                     breaks = c("WT", "znfx-1(ths434)", "ddx-19(ths636)", "npp-14(ths673)", "gle-1(ths1041)"),
                     labels = c(expression(WT), 
                                expression(italic('znfx-1(ths434)')), 
                                expression(italic('ddx-19(ths636)')), 
                                expression(italic('npp-14(ths673)')), 
                                expression(italic('gle-1(ths1041)')))) +  # Manually set legend labels to expressions
  scale_linetype_manual(values = c("WT" = "solid", 
                                   "znfx-1(ths434)" = "solid", 
                                   "ddx-19(ths636)" = "solid", 
                                   "npp-14(ths673)" = "solid", 
                                   "gle-1(ths1041)" = "solid"),
                        breaks = c("WT", "znfx-1(ths434)", "ddx-19(ths636)", "npp-14(ths673)", "gle-1(ths1041)")) +  # Manually set line styles and order
  theme_prism() +
  theme(legend.position = "top", legend.title = element_blank(), 
        legend.text = element_text(size = 10))  # Adjust the legend text size

# Keep only one legend
p <- p + guides(linetype = "none")

# Display the plot
print(p)
