import os
import subprocess

# Define input and output directories
input_dir_r2 = "/public/home/lxr/pUG/20240908_re_count_pUG/Rep1/cutadapt_discard_non_adapter/R2"
output_dir_r2 = "/public/home/lxr/pUG/20240908_re_count_pUG/Rep1/cutadapt_for_pUG/R2"

# Ensure the output directory exists
os.makedirs(output_dir_r2, exist_ok=True)

# Define the 5' adapter sequence
adapter1_rc = "TTGGGACAACTCCAGTGAAA"

# Iterate through all R2 files in the input directory
for file_name_r2 in os.listdir(input_dir_r2):
    if file_name_r2.endswith(".fastq"):
        # Get the R2 file path
        input_file_r2 = os.path.join(input_dir_r2, file_name_r2)

        # Define the output file path
        output_file_r2_final = os.path.join(output_dir_r2, file_name_r2.replace(".fastq", "_final.fastq"))

        # Trim the 5' adapter from the R2 file
        subprocess.run([
            "cutadapt",
            "-j", "8",  # Use 8 threads
            "-g", adapter1_rc,  # Specify the 5' adapter
            "-o", output_file_r2_final,
            input_file_r2
        ])

print("5' adapter trimming for R2 is completed!")
