import os
from Bio import SeqIO
from collections import Counter

# Function to count the occurrences of 'CA' or 'AC' from the start of the sequence with a limit on mismatches
def count_ca_ac_from_start(sequence, max_mismatches=1):
    count = 0
    mismatches = 0
    i = 0  # Start from the beginning of the sequence
    
    while i < len(sequence) - 1:
        # Check for 'CA' or 'AC' pairs
        if (sequence[i] == 'A' and sequence[i+1] == 'C') or (sequence[i] == 'C' and sequence[i+1] == 'A'):
            count += 1
            i += 2  # Skip the next base after detecting a match
        else:
            mismatches += 1
            i += 1  # Continue checking the next base if there is a mismatch
            if mismatches > max_mismatches:
                break  # Stop if the number of mismatches exceeds the limit
    
    return count

# Function to process a single FASTQ file and output a CSV of CA/AC counts
def process_fastq(input_fastq, output_csv):
    ca_ac_counts = Counter()  # Counter to store the counts of CA/AC occurrences
    
    with open(input_fastq, "r") as handle:
        for record in SeqIO.parse(handle, "fastq"):
            seq = str(record.seq)  # Convert sequence to string
            ca_ac_count = count_ca_ac_from_start(seq)  # Count CA/AC pairs from the start
            ca_ac_counts[ca_ac_count] += 1  # Update the count for this CA/AC occurrence
    
    with open(output_csv, "w") as output_handle:
        output_handle.write("CA_AC_Length,Count\n")  # Write headers to the CSV
        for ca_ac_count, freq in sorted(ca_ac_counts.items()):
            output_handle.write(f"{ca_ac_count},{freq}\n")  # Write the counts to the CSV

# Function to process all FASTQ files in a directory
def process_directory(input_dir, output_dir):
    # Ensure the output directory exists
    os.makedirs(output_dir, exist_ok=True)

    for file_name in os.listdir(input_dir):
        if file_name.endswith(".fastq"):
            input_fastq = os.path.join(input_dir, file_name)  # Full path to the input FASTQ file
            output_csv = os.path.join(output_dir, file_name.replace(".fastq", "_ca_ac_count.csv"))  # Output CSV path
            process_fastq(input_fastq, output_csv)  # Process the FASTQ file and save results to CSV

# Define input and output directories
input_dir = "/public/home/lxr/pUG/20240908_re_count_pUG/Rep1/cutadapt_for_pUG/R2"
output_dir = "/public/home/lxr/pUG/20240908_re_count_pUG/Rep1/count_pUG"

# Process all files in the directory
process_directory(input_dir, output_dir)

print("CA/AC counting completed for all files in the directory.")
