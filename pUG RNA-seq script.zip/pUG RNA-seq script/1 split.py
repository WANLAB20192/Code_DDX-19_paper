from Bio import SeqIO
import os

# Read index list
index_list = [
    "ACTGAT", "ATGAGC", "ATTCCT", "CAAAAG", "CAACTA", "CACCGG", "CACGAT",
    "CACTCA", "CAGGCG", "CATGGC", "TCATTC", "CCAACA", "CGGAAT", "CTAGCT",
    "CTATAC", "CTCAGA", "GACGAC", "TAATCG", "TACAGC", "TATAAT"
]

input_fastq_r1 = "/public/home/lxr/pUG/SQ24062167-pUG_mix-sample1_combined_R1.fastq"
input_fastq_r2 = "/public/home/lxr/pUG/SQ24062167-pUG_mix-sample1_combined_R2.fastq"
output_dir_r1 = "/public/home/lxr/pUG/1_Rep2/split/R1"
output_dir_r2 = "/public/home/lxr/pUG/1_Rep2/split/R2"

# Ensure the output directory exists
os.makedirs(output_dir_r1, exist_ok=True)
os.makedirs(output_dir_r2, exist_ok=True)

# Create a dictionary to store file handles corresponding to each index
output_handles_r1 = {}
output_handles_r2 = {}

# Traverse the Read 1 FASTQ file and allocate to different files based on the index
with open(input_fastq_r1, "r") as handle_r1, open(input_fastq_r2, "r") as handle_r2:
    for record_r1, record_r2 in zip(SeqIO.parse(handle_r1, "fastq"), SeqIO.parse(handle_r2, "fastq")):
        # Get the index part of the sequence (assuming the index starts from the 5th base)
        sequence_r1 = str(record_r1.seq)
        index_seq = sequence_r1[4:10]  # Start from the 5th base, 6 bases long

        if index_seq in index_list:
            # Find the corresponding output file based on the index
            index_position = index_list.index(index_seq) + 1
            output_filename_r1 = os.path.join(output_dir_r1, f"index{index_position}_{index_seq}_R1.fastq")
            output_filename_r2 = os.path.join(output_dir_r2, f"index{index_position}_{index_seq}_R2.fastq")

            # Get or create the corresponding file handles
            if index_seq not in output_handles_r1:
                output_handles_r1[index_seq] = open(output_filename_r1, "a")
                output_handles_r2[index_seq] = open(output_filename_r2, "a")

            # Write the record to the corresponding file
            SeqIO.write(record_r1, output_handles_r1[index_seq], "fastq")
            SeqIO.write(record_r2, output_handles_r2[index_seq], "fastq")

# Close all file handles
for handle in output_handles_r1.values():
    handle.close()
for handle in output_handles_r2.values():
    handle.close()

print("Index splitting completed.")
