#!/bin/bash

# Define input and output directories
input_dir_R1="/public/home/lxr/pUG/1_Rep2/split/R1"
input_dir_R2="/public/home/lxr/pUG/1_Rep2/split/R2"
output_dir="/public/home/lxr/pUG/1_Rep2/seqkit"

# Ensure the output directory exists
mkdir -p "$output_dir"

# Traverse all R1 files in the R1 directory and find the corresponding R2 files
for R1_file in "$input_dir_R1"/*_R1.fastq; do
    # Get the base file name (remove path and _R1.fastq suffix)
    base_name=$(basename "$R1_file" "_R1.fastq")
    
    # Define the corresponding R2 file
    R2_file="$input_dir_R2/${base_name}_R2.fastq"
    
    # Check if the R2 file exists
    if [[ -f "$R2_file" ]]; then
        echo "Processing file pair: $base_name_R1.fastq and $base_name_R2.fastq"
        
        # Define output file paths
        R1_output="$output_dir/${base_name}_R1_dedup.fastq"
        R2_output="$output_dir/${base_name}_R2_dedup.fastq"
        
        # Extract UMI and remove duplicates
        seqkit rmdup -s -o "$R1_output" "$R1_file"
        seqkit rmdup -s -o "$R2_output" "$R2_file"
        
        echo "UMI deduplication completed, results saved to $R1_output and $R2_output"
    else
        echo "Corresponding R2 file not found: $R2_file"
    fi
done
